/*
* Assignment 2
* @author Alp Deniz Senyurt
* Student ID: 100342433
* Self explanatory variables and parameters will not be commented as they are, "self-explanatory".
*/

#include <string>
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

int fact(int n);
double prob(int n, int k);
int strToInt(std::string str);

#endif